package com.bookstore.model;

import lombok.Data;

@Data
public class Customer {
    private Long id;
    private String name;
    private String email;
    private String address;
    
    @PostMapping("/customers")
    public Customer addCustomer(@RequestBody Customer customer) {
        customer

}
