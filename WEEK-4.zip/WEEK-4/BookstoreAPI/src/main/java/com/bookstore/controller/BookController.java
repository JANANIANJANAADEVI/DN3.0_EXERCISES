package com.bookstore.controller;

import org.springframework.web.bind.annotation.*;
import org.springframework.http.HttpStatus;
import org.springframework.http.HttpHeaders;
import org.springframework.http.ResponseEntity;

import java.util.List;  // Import List
import com.bookstore.model.Book;  // Import the Book class

@RestController
@RequestMapping("/books")
public class BookController {

    // Endpoint to get all books
    @GetMapping
    public List<Book> getAllBooks() {
        return List.of(
            new Book(1L, "Book One", "Author One", 19.99, "111-1111111111"),
            new Book(2L, "Book Two", "Author Two", 29.99, "222-2222222222")
        );
    }
    
    @GetMapping("/search")
    public List<Book> searchBooks(@RequestParam String title, @RequestParam String author) {
        // Simulating a search result
        return List.of(new Book(1L, title, author, 19.99, "111-1111111111"));
    }

    // GET: Retrieve a single book by ID
    @GetMapping("/{id}")
    public ResponseEntity<Book> getBookById(@PathVariable Long id) {
        Book book = new Book(id, "Book " + id, "Author " + id, 19.99 + id, "111-111111111" + id);
        HttpHeaders headers = new HttpHeaders();
        headers.add("Custom-Header", "HeaderValue");
        return new ResponseEntity<>(book, headers, HttpStatus.OK);
    }

    // POST: Add a new book
    @PostMapping
    @ResponseStatus(HttpStatus.CREATED)  // Custom status for successful POST request
    public Book addBook(@RequestBody Book book) {
        book.setId(3L); // Simulating adding a new book with ID 3
        return book;
    }

    // PUT: Update an existing book
    @PutMapping("/{id}")
    public Book updateBook(@PathVariable Long id, @RequestBody Book book) {
        book.setId(id);
        return book;
    }

    // DELETE: Remove a book
    @DeleteMapping("/{id}")
    public String deleteBook(@PathVariable Long id) {
        return "Book with ID: " + id + " deleted successfully!";
    }
}
