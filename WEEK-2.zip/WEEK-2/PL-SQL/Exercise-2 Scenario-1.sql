CREATE OR REPLACE PROCEDURE SafeTransferFunds (
    p_FromAccountID IN NUMBER,
    p_ToAccountID IN NUMBER,
    p_Amount IN NUMBER
) AS
    insufficient_funds EXCEPTION;
    no_account EXCEPTION;
BEGIN
    -- Check for sufficient funds
    DECLARE
        from_balance NUMBER;
    BEGIN
        SELECT Balance INTO from_balance FROM Accounts WHERE AccountID = p_FromAccountID;
        IF from_balance < p_Amount THEN
            RAISE insufficient_funds;
        END IF;
    EXCEPTION
        WHEN NO_DATA_FOUND THEN
            RAISE no_account;
    END;

    -- Transfer funds
    UPDATE Accounts SET Balance = Balance - p_Amount WHERE AccountID = p_FromAccountID;
    UPDATE Accounts SET Balance = Balance + p_Amount WHERE AccountID = p_ToAccountID;

    COMMIT;

EXCEPTION
    WHEN insufficient_funds THEN
        DBMS_OUTPUT.PUT_LINE('Error: Insufficient funds.');
        ROLLBACK;
    WHEN no_account THEN
        DBMS_OUTPUT.PUT_LINE('Error: Account not found.');
        ROLLBACK;
    WHEN OTHERS THEN
        DBMS_OUTPUT.PUT_LINE('Error: ' || SQLERRM);
        ROLLBACK;
END SafeTransferFunds;
/
