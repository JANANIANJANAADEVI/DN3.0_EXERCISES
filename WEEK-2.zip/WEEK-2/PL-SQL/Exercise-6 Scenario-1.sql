DECLARE
    CURSOR c_Transactions IS
        SELECT AccountID, TransactionDate, Amount, TransactionType
        FROM Transactions
        WHERE EXTRACT(MONTH FROM TransactionDate) = EXTRACT(MONTH FROM SYSDATE)
        AND EXTRACT(YEAR FROM TransactionDate) = EXTRACT(YEAR FROM SYSDATE);
BEGIN
    FOR rec IN c_Transactions LOOP
        DBMS_OUTPUT.PUT_LINE('Statement for Account ID: ' || rec.AccountID || 
                             ', Date: ' || rec.TransactionDate ||
                             ', Amount: ' || rec.Amount ||
                             ', Type: ' || rec.TransactionType);
    END LOOP;
END;
/
