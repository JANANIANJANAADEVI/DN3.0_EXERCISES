CREATE OR REPLACE PROCEDURE UpdateSalary (
    p_EmployeeID IN NUMBER,
    p_Percentage IN NUMBER
) AS
    employee_not_found EXCEPTION;
BEGIN
    BEGIN
        UPDATE Employees
        SET Salary = Salary + (Salary * p_Percentage / 100)
        WHERE EmployeeID = p_EmployeeID;

        IF SQL%NOTFOUND THEN
            RAISE employee_not_found;
        END IF;

        COMMIT;
    EXCEPTION
        WHEN employee_not_found THEN
            DBMS_OUTPUT.PUT_LINE('Error: Employee ID not found.');
        WHEN OTHERS THEN
            DBMS_OUTPUT.PUT_LINE('Error: ' || SQLERRM);
    END;
END UpdateSalary;
/
