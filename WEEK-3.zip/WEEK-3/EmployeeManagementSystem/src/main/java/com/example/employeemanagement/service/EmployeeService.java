package com.example.employeemanagement.service;

import com.employeemanagement.model.Employee;
import com.employeemanagement.repository.EmployeeRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import java.util.List;

@Service
public class EmployeeService {

    @Autowired
    private EmployeeRepository employeeRepository;

    @PersistenceContext
    private EntityManager entityManager;

    @Transactional
    public void saveAllEmployeesInBatch(List<Employee> employees) {
        int batchSize = 50; // Define the batch size as needed

        for (int i = 0; i < employees.size(); i += batchSize) {
            List<Employee> batchList = employees.subList(i, Math.min(i + batchSize, employees.size()));
            employeeRepository.saveAll(batchList);

            // Flush and clear the EntityManager to manage memory usage
            entityManager.flush();
            entityManager.clear();
        }
    }
}
