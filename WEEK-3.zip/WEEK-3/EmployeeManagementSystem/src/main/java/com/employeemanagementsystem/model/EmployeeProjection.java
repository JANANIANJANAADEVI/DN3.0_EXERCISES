package com.employeemanagementsystem.model;

public interface EmployeeProjection {
	String getName();
    String getEmail();
}
